package com.fucai.dto;

import com.fucai.model.OddEvenProbability;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class OddEvenProbabilityDTO extends OddEvenProbability {

}