package com.fucai.dto;

import com.fucai.model.DataLocationProbability;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class DataLocationProbabilityDTO extends DataLocationProbability {

}